import React from "react";
import styles from "../styles";
import { connect } from "react-redux";
import * as firebase from "firebase";
import Swipeout from "react-native-swipeout";

import {
  Alert,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Image
} from "react-native";

class Matches extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      chats: []
    };

  }

  deleteMatch = id => {
    firebase
      .database()
      .ref(`cards/${this.props.user.id}/chats/${id}`)
      .remove()
      .then(s => {
      })
      .catch(e => {
      });
  };
  componentWillMount() {
    this.props.navigation.setParams({ getMatches: this.getMatches });
    this.getMatches();
  }

  getMatches = () => {
    firebase
      .database()
      .ref("cards/" + this.props.user.id)
      .once("value", user => {
        firebase
          .database()
          .ref("cards/" + this.props.user.id + "/chats")
          .on("value", snap => {
            var items = [];
            snap.forEach(child => {
              firebase
                .database()
                .ref("cards/" + child.key)
                .on("value", individual => {
                  if (user.val().interested !== individual.val().interested) {
                    item = child.val();
                    items.push(item);
                  }
                });
            });
            this.setState({ chats: items.reverse() });
          });
      });
  };

  render() {
    var swipeBtns = [
      {
        text: "Delete",
        backgroundColor: "red",
        underlayColor: "rgba(0, 0, 0, 1, 0.6)",
        onPress: () => {
          this.deleteMatch(uri.user.id);
        }
      }
    ];

    return (
      <View style={styles.container}>
        <ScrollView>
          {this.state.chats.map(uri => {
            swipeBtns[0].onPress = () => this.deleteMatch(uri.user.id);
            return (
              <Swipeout
                right={swipeBtns}
                autoClose="true"
                backgroundColor="#F8F8FF"
              >
                <TouchableOpacity
                  style={[styles.imgRow, styles.border]}
                  onPress={() =>
                    this.props.navigation.navigate("Chat", {
                      user: uri.user,
                      getMatches: this.getMatches
                    })
                  }
                >
                  <Image
                    style={styles.img1}
                    source={{ uri: uri.user.photoUrl + "?width=900" }}
                  />
                  <Text style={[styles.bold1, styles.center1]}>
                    {uri.user.name}
                  </Text>
                </TouchableOpacity>
              </Swipeout>
            );
          })}
        </ScrollView>
      </View>

      ///
    );
  }
}

function mapStateToProps(state) {
  return {
    user: state.user
  };
}

export default connect(mapStateToProps)(Matches);
